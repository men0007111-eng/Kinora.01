const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
fs.mkdirSync(path.join(ROOT, "data"), {recursive:true});
fs.mkdirSync(path.join(ROOT, "uploads"), {recursive:true});

const db = new Database(path.join(ROOT, "data/kinora.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT UNIQUE NOT NULL,
 password TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS titles(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 type TEXT NOT NULL,
 genre TEXT NOT NULL,
 year INTEGER,
 description TEXT,
 poster TEXT,
 video TEXT,
 published INTEGER DEFAULT 1,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS watchlist(
 user_id INTEGER,
 title_id INTEGER,
 UNIQUE(user_id,title_id)
);
`);

const adminEmail="admin@kinora.local";
if(!db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail)){
 const hash=bcrypt.hashSync("admin123",12);
 db.prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)")
   .run("KINORA Admin",adminEmail,hash,"admin");
}
const count=db.prepare("SELECT COUNT(*) c FROM titles").get().c;
if(!count){
 const seed=[
  ["ORIGIN","movie","Drama",2026,"A premium legal-demo title.","/assets/poster1.svg",""],
  ["THE VOYAGE","movie","Sarguzasht",2026,"Adventure demo title.","/assets/poster2.svg",""],
  ["AFTER RAIN","movie","Drama",2025,"Drama demo title.","/assets/poster3.svg",""],
  ["NIGHT SHIFT","movie","Triller",2026,"Thriller demo title.","/assets/poster4.svg",""],
  ["THE FIRST CITY","series","Drama",2026,"Series demo title.","/assets/poster5.svg",""],
  ["ORBIT","series","Fantastika",2025,"Sci-fi demo title.","/assets/poster6.svg",""]
 ];
 const stmt=db.prepare("INSERT INTO titles(title,type,genre,year,description,poster,video) VALUES(?,?,?,?,?,?,?)");
 for(const x of seed) stmt.run(...x);
}

app.use(express.json({limit:"2mb"}));
app.use(express.urlencoded({extended:true}));
app.use(session({
 secret:process.env.SESSION_SECRET || "CHANGE_THIS_IN_PRODUCTION",
 resave:false, saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:"lax",secure:false,maxAge:1000*60*60*24*7}
}));
app.use("/assets",express.static(path.join(ROOT,"public/assets")));
app.use(express.static(path.join(ROOT,"public")));

const upload=multer({dest:path.join(ROOT,"uploads/"),limits:{fileSize:500*1024*1024}});

function auth(req,res,next){
 if(!req.session.user) return res.status(401).json({error:"Kirish talab qilinadi"});
 next();
}
function admin(req,res,next){
 if(!req.session.user || req.session.user.role!=="admin") return res.status(403).json({error:"Admin huquqi kerak"});
 next();
}

app.post("/api/auth/register",(req,res)=>{
 const {name,email,password}=req.body;
 if(!name||!email||!password||password.length<6) return res.status(400).json({error:"Ism, email va kamida 6 belgili parol kerak"});
 try{
  const hash=bcrypt.hashSync(password,12);
  const r=db.prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)").run(name,email.toLowerCase(),hash);
  req.session.user={id:r.lastInsertRowid,name,email:email.toLowerCase(),role:"user"};
  res.json({user:req.session.user});
 }catch(e){res.status(409).json({error:"Bu email allaqachon ro‘yxatdan o‘tgan"});}
});
app.post("/api/auth/login",(req,res)=>{
 const {email,password}=req.body;
 const u=db.prepare("SELECT * FROM users WHERE email=?").get((email||"").toLowerCase());
 if(!u||!bcrypt.compareSync(password||"",u.password)) return res.status(401).json({error:"Email yoki parol noto‘g‘ri"});
 req.session.user={id:u.id,name:u.name,email:u.email,role:u.role};
 res.json({user:req.session.user});
});
app.post("/api/auth/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/auth/me",(req,res)=>res.json({user:req.session.user||null}));

app.get("/api/titles",(req,res)=>{
 const {q,type,genre}=req.query;
 let sql="SELECT * FROM titles WHERE published=1"; const p=[];
 if(q){sql+=" AND title LIKE ?";p.push("%"+q+"%")}
 if(type){sql+=" AND type=?";p.push(type)}
 if(genre){sql+=" AND genre=?";p.push(genre)}
 sql+=" ORDER BY id DESC";
 res.json(db.prepare(sql).all(...p));
});
app.get("/api/titles/:id",(req,res)=>{
 const t=db.prepare("SELECT * FROM titles WHERE id=? AND published=1").get(req.params.id);
 if(!t)return res.status(404).json({error:"Topilmadi"});res.json(t);
});
app.get("/api/watchlist",auth,(req,res)=>{
 res.json(db.prepare("SELECT t.* FROM titles t JOIN watchlist w ON w.title_id=t.id WHERE w.user_id=?").all(req.session.user.id));
});
app.post("/api/watchlist/:id",auth,(req,res)=>{
 db.prepare("INSERT OR IGNORE INTO watchlist(user_id,title_id) VALUES(?,?)").run(req.session.user.id,req.params.id);
 res.json({ok:true});
});
app.delete("/api/watchlist/:id",auth,(req,res)=>{
 db.prepare("DELETE FROM watchlist WHERE user_id=? AND title_id=?").run(req.session.user.id,req.params.id);res.json({ok:true});
});

app.get("/api/admin/stats",admin,(req,res)=>{
 res.json({
  users:db.prepare("SELECT COUNT(*) c FROM users").get().c,
  titles:db.prepare("SELECT COUNT(*) c FROM titles").get().c,
  published:db.prepare("SELECT COUNT(*) c FROM titles WHERE published=1").get().c,
  watchlist:db.prepare("SELECT COUNT(*) c FROM watchlist").get().c
 });
});
app.get("/api/admin/titles",admin,(req,res)=>res.json(db.prepare("SELECT * FROM titles ORDER BY id DESC").all()));
app.post("/api/admin/titles",admin,(req,res)=>{
 const {title,type,genre,year,description,poster,video,published=1}=req.body;
 if(!title||!type||!genre)return res.status(400).json({error:"Majburiy maydonlar yetishmayapti"});
 const r=db.prepare("INSERT INTO titles(title,type,genre,year,description,poster,video,published) VALUES(?,?,?,?,?,?,?,?)")
  .run(title,type,genre,Number(year)||null,description||"",poster||"",video||"",published?1:0);
 res.json(db.prepare("SELECT * FROM titles WHERE id=?").get(r.lastInsertRowid));
});
app.put("/api/admin/titles/:id",admin,(req,res)=>{
 const old=db.prepare("SELECT * FROM titles WHERE id=?").get(req.params.id);if(!old)return res.status(404).json({error:"Topilmadi"});
 const x={...old,...req.body};
 db.prepare("UPDATE titles SET title=?,type=?,genre=?,year=?,description=?,poster=?,video=?,published=? WHERE id=?")
 .run(x.title,x.type,x.genre,Number(x.year)||null,x.description||"",x.poster||"",x.video||"",x.published?1:0,req.params.id);
 res.json(db.prepare("SELECT * FROM titles WHERE id=?").get(req.params.id));
});
app.delete("/api/admin/titles/:id",admin,(req,res)=>{
 db.prepare("DELETE FROM titles WHERE id=?").run(req.params.id);res.json({ok:true});
});
app.get("/api/admin/users",admin,(req,res)=>{
 res.json(db.prepare("SELECT id,name,email,role,created_at FROM users ORDER BY id DESC").all());
});

app.post("/api/admin/upload",admin,upload.single("file"),(req,res)=>{
 if(!req.file)return res.status(400).json({error:"Fayl yuborilmadi"});
 res.json({filename:req.file.filename,original:req.file.originalname,size:req.file.size,
   note:"Development upload. Productionda object storage/CDN va video transcoding ishlating."});
});

app.listen(PORT,()=>console.log(`KINORA running: http://localhost:${PORT}`));
