# KINORA — Full-stack legal streaming starter

Professional full-stack starter for a legal movie/series platform.

## Stack
- Frontend: HTML, CSS, Vanilla JS
- Backend: Node.js + Express
- Database: SQLite
- Auth: bcrypt password hashing + session cookies
- Uploads: local storage for development
- JSON: seed data / API
- C++: intentionally NOT used. C++ is not a normal choice for a web app; Node.js is used for the backend.

## Run
1. Install Node.js 20+
2. `npm install`
3. `npm start`
4. Open `http://localhost:3000`

Demo admin:
- Email: admin@kinora.local
- Password: admin123

For production, change the admin password, session secret, use HTTPS, object storage/CDN, a real payment provider, database backups, rate limiting and proper copyright/licensing workflows.

Only upload or stream content for which you have the necessary rights.
